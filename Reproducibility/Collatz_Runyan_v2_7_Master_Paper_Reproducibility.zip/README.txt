COLLATZ–RUNYAN FRAMEWORK v2.7 | Master Research Synthesis
Local audit edition, 28 November 2026. For author review, not an assigned v2.7 DOI.

Contents
- master.tex: complete LaTeX manuscript source (compile twice with pdflatex).
- figures/: 23 original vector PDF figures and Graphviz DOT source.
- plot_crf.py: Python generator. Requires Python 3, NumPy, Matplotlib; Graphviz dot for import graph.
- module_inventory.csv: all 64 module counts extracted from successful user terminal transcript.
- spectral_theorem_index.csv: 496 fully qualified audit command names and exact source line numbers.
- stage6_certificates.json: source package certificate table used in CRT arithmetic.
- SHA256SUMS.txt: fingerprints of files in this supplementary archive.

Reproduce figures: python plot_crf.py --output figures
Rebuild paper: pdflatex master.tex (twice).
The source-derived spectral name index is not the complete local audit JSON. Preserve the actual local declaration-inventory.json and logs for publication.
All finite simulations/plots are illustrative; they do not prove Collatz convergence or validate a physical model.
Canonical source hashes:
Geometric Stage1–6: 04a5a51a967e030f7a6da3eccdfded19c39f93ff8fc02b6db148669dfd02034b
Lepton Stage1–9: 98bd3767cb0ab260f51f015d61d5f9013925d32c18c6981925bec82c089301ba
