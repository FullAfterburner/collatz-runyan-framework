#!/usr/bin/env python3
"""Deterministic figures for CRF v2.7 research synthesis. Python 3, NumPy, Matplotlib.
All plots are computed illustrations; no finite test is a proof of convergence.
Run: python plot_crf.py --output figures
"""
import argparse, math
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from itertools import product
p=argparse.ArgumentParser();p.add_argument('--output',default='figures');args=p.parse_args();out=Path(args.output);out.mkdir(exist_ok=True,parents=True)
plt.rcParams.update({'font.size':10,'axes.labelsize':10,'axes.titlesize':12,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':150,'savefig.dpi':200,'font.family':'DejaVu Sans','axes.grid':True,'grid.alpha':.18,'legend.frameon':False})
blue='#244b74';teal='#007e85';orange='#b85a2b';gray='#728091';purple='#7455a4'
def save(fig,name):
 fig.tight_layout();fig.savefig(out/(name+'.pdf'),bbox_inches='tight');plt.close(fig)
def T(n):return n//2 if n%2==0 else (3*n+1)//2
def orbit(n,cap=10000):
 a=[n]
 while a[-1]!=1 and len(a)<=cap:a.append(T(a[-1]))
 return a
# 1. inventory
fig,ax=plt.subplots(figsize=(7.2,3.4)); labels=['v2.4','v2.5','v2.6','v2.7'];vals=[305,418,560,1056]; bars=ax.bar(labels,vals,color=[gray,gray,blue,teal]);ax.bar_label(bars,padding=3);ax.set_ylim(0,1170);ax.set_ylabel('Distinct audited names');save(fig,'audit_growth')
# 2. orbits
fig,ax=plt.subplots(figsize=(7.3,3.8))
for n,c in [(7,gray),(27,blue),(97,orange),(871,teal)]:
 a=orbit(n);ax.plot(range(len(a)),a,label=f'n = {n} ({len(a)-1} steps)',lw=1.3,color=c)
ax.set_yscale('log');ax.set_xlabel('Shortcut steps');ax.set_ylabel('Orbit value (log scale)');ax.legend(ncol=2);save(fig,'orbits')
# 3. inverse tree (rooted at 1, avoid already visited)
levels=[[1]];edges=[];seen={1}
for d in range(8):
 nextlevel=[]
 for n in levels[-1]:
  for m in [2*n]+([(2*n-1)//3] if (2*n-1)%3==0 and (2*n-1)//3%2==1 else []):
   if m>0 and m not in seen:seen.add(m);nextlevel.append(m);edges.append((n,m))
 levels.append(nextlevel)
fig,ax=plt.subplots(figsize=(7.5,5.3));pos={n:(i-(len(l)-1)/2,-d) for d,l in enumerate(levels) for i,n in enumerate(l)}
for n,m in edges:
 x,y=pos[n];xx,yy=pos[m];ax.plot([x,xx],[y,yy],color=gray,lw=.7)
for n,(x,y) in pos.items():ax.scatter(x,y,s=28,color=teal if n%2 else blue,zorder=3);ax.text(x,y+.12,str(n),fontsize=7,ha='center')
ax.axis('off');save(fig,'inverse_tree')
# 4. finite residue parity map
k=8;grid=[]
for n in range(1,2**k+1):
 w=[];a=n
 for j in range(k):w.append(a%2);a=T(a)
 grid.append(w)
fig,ax=plt.subplots(figsize=(7,4));ax.imshow(np.array(grid).T,aspect='auto',interpolation='nearest',cmap=ListedColormap([blue,orange]));ax.set_yticks(range(k),range(1,k+1));ax.set_xlabel('Residue representative r − 1 (mod 256)');ax.set_ylabel('Step');ax.grid(False);save(fig,'parity_cylinders')
# 5. finite observed prefix frequencies and critical threshold
fig,ax=plt.subplots(figsize=(7.1,3.7))
for n,c in [(27,blue),(97,orange),(871,teal),(2**16-1,purple)]:
 a=orbit(n);v=np.cumsum(np.array(a[:-1])%2)/np.arange(1,len(a));ax.plot(np.arange(1,len(a)),v,label=str(n),lw=1.2,color=c)
ax.axhline(math.log(2)/math.log(3),color='black',ls='--',label='log(2)/log(3)');ax.axhline(5/8,color=gray,ls=':',label='5/8');ax.set(xlabel='Prefix length k',ylabel='Odd fraction',ylim=(0,1.04));ax.legend(ncol=3);save(fig,'parity_frequency')
# 6. cycle budget window
m=np.arange(1,51);fig,ax=plt.subplots(figsize=(7.1,3.6));base=m*np.log2(3);ax.plot(m,base,c=blue,label='Lower boundary m log₂ 3');
for N,c in [(3,orange),(27,teal),(100,gray)]:ax.plot(m,m*np.log2(3+1/N),c=c,label=f'Upper, N={N}')
for j in range(1,51):
 for K in range(math.floor(base[j-1])+1,math.floor(j*math.log2(3+1/3))+1):ax.scatter(j,K,s=5,c=orange,alpha=.35)
ax.set(xlabel='Odd cycle length m',ylabel='Total binary budget K');ax.legend(fontsize=8);save(fig,'cycle_window')
# 7. least missing residue grid CRT
s256={27,31,47,71,91,103,111,127,155,159,167,191,231,239,251,255};s9={0,1,3,6,7};a=np.array([[int(r in s256 and t in s9) for r in range(256)] for t in range(9)])
fig,ax=plt.subplots(figsize=(7.4,2.8));ax.imshow(a,aspect='auto',interpolation='nearest',cmap=ListedColormap(['#e6edf2',teal]));ax.set(xlabel='Residue mod 256',ylabel='Residue mod 9');ax.set_yticks(range(9));ax.grid(False);save(fig,'residue_sieve')
# 8. hypothetical doubling-only defect, not a counterexample
fig,ax=plt.subplots(figsize=(7.2,3.5));t=np.logspace(-5,1,400)
for n,c in [(3,blue),(11,teal),(27,orange)]:
 d=2*np.exp(-np.pi*t[:,None]*(n*2.**np.arange(20)[None,:])**2).sum(axis=1);ax.plot(t,d,label=f'hypothetical n₀={n}',c=c)
ax.set_xscale('log');ax.set(xlabel='Theta parameter t',ylabel='Partial doubling-family weight');ax.legend();save(fig,'theta_defect')
# 9. theta kernel surface (continuous plotting variables)
fig=plt.figure(figsize=(7.1,4.4));ax=fig.add_subplot(projection='3d');n=np.linspace(1,6,100);t=np.geomspace(.02,2,100);X,Y=np.meshgrid(n,t);Z=np.exp(-np.pi*X*X*Y);ax.plot_surface(X,np.log10(Y),Z,cmap='viridis',linewidth=0,antialiased=True);ax.set(xlabel='n (continuous display)',ylabel='log₁₀(t)',zlabel='exp(−π n² t)');ax.view_init(26,-126);save(fig,'theta_surface')
# 10. Basel defect from hypothetical doubling family
n=np.arange(1,101);fig,ax=plt.subplots(figsize=(7.1,3.3));ax.loglog(n,1/n**2,label='Single term 1/n²',c=blue);ax.loglog(n,4/(3*n**2),label='Doubling family 4/(3n²)',c=orange,ls='--');ax.set(xlabel='Hypothetical missing seed n',ylabel='Lower bound on positive defect');ax.legend();save(fig,'basel_gap')
# 11. cylinder residues and pole amplification
k=np.arange(0,25);fig,ax=plt.subplots(figsize=(7.1,3.3));ax.semilogy(k,(4/3)**k,c=teal,label='Residue of Fₖ at s=1');ax.semilogy(k,np.ones_like(k),c=gray,ls='--',label='Normalized residue');ax.set(xlabel='Finite iteration depth k',ylabel='Residue (log scale)');ax.legend();save(fig,'hurwitz_residue')
# 12. target matrix candidates
pts=[(a,b) for a in range(-6,27) for b in range(-16,17) if (a-10)**2+b*b==234];fig,ax=plt.subplots(figsize=(5.6,4.5));t=np.linspace(0,2*np.pi,300);ax.plot(10+np.sqrt(234)*np.cos(t),np.sqrt(234)*np.sin(t),color=gray);ax.scatter(*zip(*pts),color=blue,s=35);ax.scatter([7,13],[15,15],color=orange,s=80,label='Entrywise nonnegative H');ax.axvline(0,c=gray,lw=.6);ax.axvline(20,c=gray,lw=.6);ax.axhline(0,c=gray,lw=.6);ax.set_aspect('equal');ax.set(xlabel='Diagonal entry a (d=20−a)',ylabel='Off-diagonal b');ax.legend(fontsize=8);save(fig,'integer_circle')
# 13. Gram and covariance ratios
ks=np.arange(2,41,dtype=float);x=(5/4)**ks;h=x-1;y=(4/3)**ks;g=y-1
S=np.array([[ [H,1.5*H-k/4],[1.5*H-k/4,3.5*H-.75*k-k*k/16]] for k,H in zip(ks,h)]);O=np.array([[[G,G/2-k/4],[G/2-k/4,G-k/4-k*k/16]] for k,G in zip(ks,g)])
def ratio(M):e=np.linalg.eigvalsh(M);return np.sqrt(e[:,1]/e[:,0])
rs=(10+3*np.sqrt(26))/(3*np.sqrt(26)-10);fig,ax=plt.subplots(figsize=(7.2,3.6));ax.plot(ks,ratio(S),c=blue,label='Forward covariance');ax.plot(ks,ratio(O),c=teal,label='Inverse covariance');ax.axhline(rs,c=orange,ls='--',label='Target ratio');ax.set(xlabel='Word length k',ylabel='√(λmax/λmin)');ax.legend();save(fig,'covariance_ratios')
# 14. forward word point geometry
k=7;pts=[]
for w in product([0,1],repeat=k):
 a,b=1.,0.
 for odd in w:a,b=((1.5*a,1.5*b+.5) if odd else (.5*a,.5*b))
 pts.append((a,b,sum(w)))
pts=np.array(pts);fig,ax=plt.subplots(figsize=(7.1,4));s=ax.scatter(pts[:,0],pts[:,1],c=pts[:,2],cmap='viridis',s=15);fig.colorbar(s,ax=ax,label='Odd count');ax.set(xlabel='α',ylabel='β');save(fig,'affine_cloud')
# 15. covariance geometry 3d positive quadratic surfaces
fig=plt.figure(figsize=(7.2,4.4));ax=fig.add_subplot(projection='3d');a=np.linspace(-2,2,65);X,Y=np.meshgrid(a,a);Z=X*X+3*X*Y+3.5*Y*Y;ax.plot_surface(X,Y,Z,cmap='viridis',linewidth=0);ax.set(xlabel='u',ylabel='v',zlabel='q(u,v)');ax.view_init(30,-125);save(fig,'covariance_surface')
# 16. Q random word, truncated finite simulation
rng=np.random.default_rng(20261128);N=10000;R=np.ones(N);Z=np.zeros(N);snap={}
for i in range(160):
 odd=rng.random(N)<.75;Z+=odd*R/3;R*=np.where(odd,2/3,2)
 if i+1 in (20,80,160):snap[i+1]=Z.copy()
fig,ax=plt.subplots(figsize=(7.1,3.7));
for k,c in zip(snap,[gray,blue,teal]):
 v=np.sort(snap[k]);surv=(N-np.arange(N))/N;ax.loglog(v,surv,c=c,label=f'k={k}')
a=np.geomspace(3,1000,100);ax.loglog(a,1/(2*np.log(4/3)*a),ls='--',c=orange,label='Asymptotic 1/x reference');ax.set(xlabel='Finite correction Zₖ',ylabel='Empirical survival');ax.legend();save(fig,'perpetuity')
# 17. fractional moment function
s=np.linspace(0,1,300);m=.25*2**s+.75*(2/3)**s;fig,ax=plt.subplots(figsize=(7.1,3.3));ax.plot(s,m,c=teal);ax.axhline(1,c=gray,ls='--');ax.set(xlabel='Real moment order s',ylabel='m(s)');save(fig,'moment_function')
# 18. empirical comparison and hierarchy
me=.51099895069;f=lambda j:1+np.sqrt(2)*np.cos(2/9+2*np.pi*j/3);mu=me*(f(2)/f(1))**2;tau=me*(f(0)/f(1))**2;S=(20+14/17)/(17-tau/mu);scale=40/S;n1=scale*(3*np.sqrt(26)-10);n2=scale*(3*np.sqrt(26)+10);n3=n2+(134*scale-n2)/(1-1.25*np.sin(np.pi/12)**2);d21=(n2*n2-n1*n1)*1e-6;d31=(n3*n3-n1*n1)*1e-6
fig,ax=plt.subplots(figsize=(7.1,3.1));vals=[n1,n2,n3];bars=ax.bar(['m₁','m₂','m₃'],vals,color=[blue,teal,orange]);ax.bar_label(bars,fmt='%.3f',padding=3);ax.set(ylim=(0,58),ylabel='Model mass (meV)');save(fig,'neutrino_masses')
fig,ax=plt.subplots(figsize=(7.1,3.3));vals=[(mu-105.6583755)/.0000023,(tau-1776.93)/.09,(d21-7.388e-5)/.078e-5,(d31-2.509e-3)/.027e-3];ax.barh(['Muon','Tau','Solar splitting','Atmospheric splitting'],np.abs(vals),color=[orange,blue,teal,teal]);ax.set_xscale('log');ax.axvline(1,color=gray,ls='--');ax.set(xlabel='Absolute residual / quoted experimental uncertainty',xlim=(.25,1000));save(fig,'benchmark_residuals')
print('Model values:',mu,tau,n1,n2,n3,d21,d31)
# 20. Import dependency graph from v2.7 baseline import inspection.
# Optional Graphviz installation required for this one figure.
import shutil, subprocess
edges=[('SparseCoefficientRigidity','FamilyCoefficientRigidity'),('FamilyCoalescenceRigidity','FamilyCoefficientRigidity'),('FamilyCorrectionProduct','FamilyCoefficientRigidity'),('FamilyCoefficientRigidity','AsymptoticCoefficientRigidity'),('AsymptoticCoefficientRigidity','ParityDriftConflict'),('BinarySpectralSymmetry','BinaryDynamicalCompatibility'),('BinaryDynamicalCompatibility','BinarySpectralIteration'),('BinarySpectralIteration','BinaryAdelicDuality'),('BinaryAdelicDuality','CollatzAdelicCompatibility'),('CollatzAdelicCompatibility','CollatzAdelicDrift'),('CollatzAdelicDrift','CollatzCorrectionBounds'),('ParityDriftConflict','CollatzIterationBridge'),('CollatzCorrectionBounds','CollatzIterationBridge'),('CollatzIterationBridge','IntegratedNonDescentRigidity'),('IntegratedNonDescentRigidity','CollatzCycleBudget'),('CollatzCycleBudget','CollatzCycleExclusionCertificate'),('CollatzCycleExclusionCertificate','CollatzCycleMinimumRigidity'),('CollatzCycleMinimumRigidity','CollatzCycleAffineRigidity'),('CollatzCycleAffineRigidity','CollatzCycleAdmissibility'),('CollatzCycleAdmissibility','CollatzCyclicRotationRigidity'),('BinaryConjugation','ConjugateCoefficientRigidity'),('ConjugateCoefficientRigidity','ConjugateCycleRigidity'),('BinaryConjugation','TwoAdicSectorDecomposition')]
if shutil.which('dot'):
 nodes=sorted(set(sum(([a,b] for a,b in edges),[])))
 def label(s):
  import re
  parts=re.findall('[A-Z][a-z]*',s);return '\\n'.join(' '.join(parts[i:i+2]) for i in range(0,len(parts),2))
 dot='digraph CRF { graph [rankdir=TB,bgcolor="white",nodesep=.16,ranksep=.22]; node [shape=box,style="rounded,filled",fillcolor="#e5eef4",color="#244b74",fontname="DejaVu Sans",fontsize=10,margin=".07,.04"]; edge [color="#728091",arrowsize=.5];\n'
 dot+='\n'.join(f'"{n}" [label="{label(n)}"];' for n in nodes)+'\n'
 dot+='\n'.join(f'"{a}" -> "{b}";' for a,b in edges)+'\n}'
 (out/'dependency_graph.dot').write_text(dot);subprocess.run(['dot','-Tpdf',str(out/'dependency_graph.dot'),'-o',str(out/'dependency_graph.pdf')],check=True)
# 21. Example vacuum potential for l=k=b=v=1, algebraic illustrative slice.
fig,ax=plt.subplots(figsize=(6.4,4.4));u=np.linspace(-1.35,1.35,250);X,Y=np.meshgrid(u,u);V=(X*X+Y*Y-1)**2+(X*X+Y*Y)*(X*X-3*Y*Y)**2;cs=ax.contourf(X,Y,np.log10(1+V),levels=25,cmap='viridis');fig.colorbar(cs,ax=ax,label='log₁₀(1+V)');ax.scatter([np.sqrt(3)/2,np.sqrt(3)/2,-np.sqrt(3)/2,-np.sqrt(3)/2],[.5,-.5,.5,-.5],c='white',edgecolors='black',s=34,label='Exact zeros');ax.set_aspect('equal');ax.set(xlabel='x',ylabel='y');ax.legend();save(fig,'vacuum')
# 22. Trace invariant for the unweighted Gram recurrence.
k=np.arange(0,31,dtype=float);x=(5/4)**k;tr=(18*x-10-3*k)/4;det=(5*x*x+(8-3*k)*x-9)/4;fig,ax=plt.subplots(figsize=(7.1,3.3));ax.plot(k,tr/np.sqrt(det),color=blue,label='Defined Gram ensemble');ax.axhline(np.sqrt(20),c=teal,ls=':',label='Proven upper bound');ax.axhline(334/67,c=orange,ls='--',label='Target');ax.set(xlabel='Word length k',ylabel='Trace / √det');ax.legend();save(fig,'gram_bound')
# 23. Exact rational record-growth exponents, from the four named source theorems.
fig,ax=plt.subplots(figsize=(7.1,3.1));values=[2/3,8/9,9/10,29/32];bars=ax.bar(['Bounded','Sparse','Coalescent','Family'],values,color=[gray,blue,blue,teal]);ax.bar_label(bars,labels=['2/3','8/9','9/10','29/32'],padding=4);ax.set(ylim=(0,1.06),ylabel='Record coefficient exponent');save(fig,'record_exponents')

# Stage 6 sieve arithmetic, using the archived certificate table if supplied.
import json
certificate_file=Path(__file__).with_name('stage6_certificates.json')
if certificate_file.exists():
    certs=json.loads(certificate_file.read_text())
    survivors={r for r in range(9216) if r%256 in s256 and r%9 in s9}
    exclusions={c['r'] for c in certs}
    assert len(certs)==len(exclusions)==90 and exclusions<=survivors
    assert len(survivors)==320 and len(survivors-exclusions)==230
    print('CRT survivors after certificates:',len(survivors-exclusions),'/ 9216')
print('Figures generated:',len(list(out.glob('*.pdf'))))
